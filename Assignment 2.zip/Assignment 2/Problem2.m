K = 3; % number of components
mu = cell(K,1);
S = cell(K,1);
p = [.3; .4; .3];
mu{1} = [0; 2];
mu{2} = [1; -3];
mu{3} = [5; 0];
theta = pi/8; G = [cos(theta) -sin(theta); sin(theta) cos(theta)];
S{1} = G*[5 0; 0 .1]*G';
theta = 3*pi/4; G = [cos(theta) -sin(theta);sin(theta) cos(theta)];
S{2}= G*[3 0; 0 .5]*G';
S{3} = [1 0; 0 4];

%% PART 1
N = 500;
X= GMM_Generator(N, mu, S, p);

%% Part 2, 3, 4, 5
plot = 1; %show the animation while performing GMM
[mu2,s2,p2] = GMM(X, plot);


