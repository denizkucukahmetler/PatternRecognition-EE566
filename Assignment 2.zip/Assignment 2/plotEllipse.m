function ell = plotEllipse(mu,S,percent)
if nargin==2
percent = 0.9;
end
r = sqrt(chi2inv(percent,2));
t = linspace(0,2*pi,501); t(end) = [];
u = r*[cos(t); sin(t)]; % transform to ellipse
[V,D]=eig(S);
ell = repmat(mu,1,500)+ V*sqrt(D)*u;


plot(ell(1,:),ell(2,:));