function [mu, S,eps, alpha, beta, lambda,psi,lh_array] = HMM(X, K, S, mu,p)

%Initializations
size_x = size(X);
N = size_x(2);

alpha = ones(N,K);
beta = ones(N,K);
psi =  [1/3 1/3 1/3;
        1/3 1/3 1/3;
        1/3 1/3 1/3];

lambda = ones(N,K);
eps = ones(N,K,K);


T_max = 200; %Determine the number of maximum iterations
lh_array = zeros(3,T_max); %Array to keep the likelihoods per iteration

for t=1:T_max
%%%%%%%%%%%%%%%%%%%%%%%%    E-step    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%At E-step, the parameters of alpha, beta, lambda, epsilon are updated.

%ALPHA Update - This parameter is used for forward procedure. 
for k=1:K
    alpha(1,k) = p(k)*mvnpdf(X(:,1),mu{k}, S{k});
end


for i =2:N
    for r = 1:K
        summ = 0;
        for k=1:K 
           summ = summ + alpha(i-1,k)*psi(k,r);  
        end

        alpha(i, r) = summ*mvnpdf(X(:,i), mu{r}, S{r});
    end
end

%BETA Update - This parameter is used for backward procedure.
beta(N,:) = 1;
for i =N-1:-1:1
   for k =1:K
       summ = 0;
       for r = 1:K
           summ = summ + psi(k,r)*mvnpdf(X(:,i+1), mu{r}, S{r})*beta( (i+1),r);
       end
       beta(i, k) = summ;
   end
end
%LAMBDA Update - This parameter is used to keep the data log likelihoods.
for  i =1:N
   for r =1:K
        num = alpha(i,r).*beta(i,r) ;
        denom = 0;
        for k = 1:3
            denom = denom + alpha(i,k)*beta(i,k);
        end
        lambda(i, r) = num / denom;
   end
end
%EPSILON - This parameter is used for backward procedure.
  for i=1:N-1
    denom = 0;
    for r = 1:K
        for q =1:K
            num = alpha(i,r)*psi(r,q)*mvnpdf(X(:,i+1))*beta((i+1),q);
            denom = denom+alpha(i,r)*psi(r,q)*mvnpdf(X(:,i+1),mu{q},S{q})*beta((i+1),q);          
        end
    end
    for r=1:K
        for q=1:K
            eps(i,r,q) = num /denom;     
        end            
    end

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  M-step  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%

%Pi - Prior Probabilities
p = lambda(1,:);

%PSI Update - Psi matrix keeps the transition probabilities.
for r=1:K
    for q=1:K
        psi(r,q) = sum(eps(:,r,q))/sum(lambda(:,r));
    end
end

%MU Update - MU matrix keeps the mean values of the classes.
for k = 1:K
    num = 0;
    denom = 0;
    for i = 1:N
        num = num + lambda(i,k)*X(:,i);
    end
    for i = 1:N
        denom = denom + lambda(i,k);
    end
    mu{k} = num / denom;
end
%SIGMA Update - Sigma matrix keeps the covariance matrices for the classes.
for k=1:K
    num = 0;
    denom = 0;
    for i = 1:N
        num = num + lambda(i,k).*(X(:,i)-mu{k})*(X(:,i)-mu{k})';
    end
    for i = 1:N
        denom = denom + lambda(i,k);
    end
    S{k} = num/denom;

end
%Likelihoods for the first 3 instances of class 1:
lh_array(1,t) = lambda(1,1);
lh_array(2,t) = lambda(1,2);
lh_array(3,t) = lambda(1,3);

end