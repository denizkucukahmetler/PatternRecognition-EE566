function [mu, S, p] = GMM(X,plot)
    
    size_x = size(X); 
    N = size_x(2); %Find component number

    %STEP 1: set K 
    K =3;
    %STEP 2: set number of iterations T
    T_max = 200;
    %STEP 3: initialize GMM parameters
    p = [1/3, 1/3, 1/3]; %the prior probabilities
    S = cell(K,1); %This cell will be filled with the Sigmas (covariance matrices) of each class k in K classes.
    mu = cell(K,1);%This cell will be filled with the means of each class k in K classes.
    qs =[];
    %Below, mu's are initialized randomly as it is a preferable
    %initialization way.
    mu{1} = randn(2,1); 
    mu{2} = randn(2,1);
    mu{3} = randn(2,1);
    %Below, covariance matrices are initialized with the identity matrix of
    %size 2x2. 
    S{1} = eye(2);
    S{2}= eye(2);
    S{3} = eye(2);
    
    qi=zeros(K,N);
    
    %STEP 4: for each iteration perform E-step and M-step
    for t=1:T_max
        %Before starting the EM algorithm (before updating the parameters),
        %the previous iteration's prior probability is kept to check the
        %convergence after updating the parameters through the algorithm.
        p_prev = p;
        %%%%%%%%%%%%%%%%%%%%%%%%%    E-step    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %At E-step, given the data and the given parameters, the expected
        %value of the data log likelihood is calculated. The expectations
        %are kept at the q matrix.
        for j=1:N 
            for k=1:K
                q(k,j)= (mvnpdf(X(:,j),mu{k},S{k}))*p(k); 
                %First index of q matrix denotes the class index 
                %Second index of q matrix denotes the data point index
            end
        end
        q=q./sum(q);
            
        %%%%%%%%%%%%%%%%%%%%%%%%    M-step    %%%%%%%%%%%%%%%%%%%%%%%%
        
        %At M-step: parameters mu, sigma and prior probabilities are
        %updated by probabilistic maximization using the expectations
        %computed at E-step.
        for k = 1:K
           
           %UPDATE MU
           num = 0;
           denom = 0;
           for i = 1:N
            num = num + q(k,i)*X(:,i);
            denom = denom + q(k,i);
           end
           mu{k} = num / denom; %mu of the class k is updated
        end
           %UPDATE S
           
           for k=1:K
               num = 0;
               denom = 0;
               for i=1:N
                num = num + q(k,i)*(X(:,i)*X(:,i)');
                denom = denom + q(k,i);
               end
               S{k} = (num / denom) - (mu{k}*mu{k}'); %Sigma of the class k is updated
           end
           
           %UPDATE P
           p(k) = 0;
           for i = 1: N
               p(k) = p(k) + q(k,i);
           end
           p(k) = 1/N*p(k); %P of the class k is updated
     
        %STEP 5: Check convergence, stop if algorithm doesn't improve.
        %The convergence if checked by comparing the classes' prior
        %probabilities. If the improvement of the probability value is less
        %than 0.000001, then the algorithm is said to be converged.
        
            if  t>1 && (abs(p(1)-p_prev(1)) <= 0.000001) &&  (abs(p(3)-p_prev(3)) <= 0.000001) &&  (abs(p(3)-p_prev(3)) <= 0.000001)
                break;
            end
           
%DATA - ELLIPSES PLOTTING PART
%    figure(); %uncomment to see the improvement on different figures
if plot %If the plot parameter is 1, the function will show the found clusters in an animation.
  
     scatter(X(1,:),X(2,:));
    hold on;
    for k=1:K
         plotEllipse(mu{k},S{k},p(k));
         drawnow;
         pause(0.1);
    end
         clf;
end
% LIKELIHOOD PLOTTING PART
%     Uncomment line 107, 108, 115, 116 to plot the likelihoods for 1th, 10th and 20th
%     iterations.
%     if (t == 1) || (t == 10) || (t == 20) 
%     plot(q(1,:),"DisplayName", num2str(t));

%   Uncomment line 117 to plot the likelihood as a function of
%   iteration number.
    ave = mean(mean(q(1,:)));qs = [qs; ave]; 
    
    end
%      hold off
%      legend
%     plot([1:t-1], qs');
end