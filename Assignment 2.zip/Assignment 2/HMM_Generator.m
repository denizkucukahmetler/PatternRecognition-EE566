function [X,cats] = HMM_Generator(N, mu, cov, p, t)
    X = zeros(2,N);
    cats = zeros(1, N);
    
    a = 1;
    b = 0;
    r = (b-a).*rand(N,1) + a; %randomly generate N numbers in the range (0,1)
 
    %generate the first data using the priors
    if r(1) < 0.3                      %map to class 1 if random number is in [0-0.3)
            cat = 1;
        elseif 0.3<=r(1) && r(1) <0.7    %map to class 2 if random number is in [0.3-0.7)
            cat = 2;  
        else                                 %map to class 3 if random number is in [0.7-1)
            cat = 3; 
    end
    cats(1) = cat;
    
    prev = 1;
    %generate the rest of the data with their categories using the transitions
    for ran=2:N               
        cat = cats(prev);
        row = t(cat,:);
        if r(ran) < row(1) 
            cats(ran) = 1;
        elseif r(ran) < (row(1) + row(2))
            cats(ran) = 2; 
        else
            cats(ran) = 3;
        end
        prev = prev +1;
    end
    
    normal_ins = randn(2,N);
    for k=1:N
        j = cats(k);
        [G, D] = eig(cell2mat(cov(j)));
        instance = G*sqrt(D)*normal_ins(:,k) +cell2mat(mu(j));
        X(:,k) = instance;
    end
end