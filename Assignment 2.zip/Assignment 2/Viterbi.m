function [labels] = Viterbi(X, N, K, S, mu,p,t)



f = zeros(K,N); %The probability in each step is kept in this matrix.

%Initialize the first probabilities of f:
for k=1:K
            f(k,1) = log(p(k))+log(mvnpdf(X(:,1),mu{k},S{k}));
end
        
%Forward Pass:
for i = 2:N
    for r =1:K
        max_q = 0;
        max = intmin;
        for q=1:K
            sum = f(q,i-1)+log(t(q,r))+log(mvnpdf(X(:,i),mu{r}, S{r})); %RECURSION
            if sum>max
                max_q = q;
                max = sum;
            end
        end
        f(r, i) = max; %Obtain the max probability considering the previous states per instance per class.
    end
    
end

%Backtrace to get the labels:
labels = zeros(1,N);
max = intmin;

for k =1:K
    if f(k,N)>max
        max = f(k,N);
        label = k;
    end
end
labels(N) = label;

for i = N-1:-1:1
    max = intmin;
    for k =1:K
        if f(k,i)>max
            max = f(k,i);
            label = k;
        end
    end
    labels(i) = label;
end

