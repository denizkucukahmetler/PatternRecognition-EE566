clear all;

%We generate 500 samples again instead of taking from Problem 3a since HMM
%is executed for less than 500 samples in that problem.
N = 500;
mu{1} = [0; 2];
mu{2} = [1; -3];
mu{3} = [5; 0];
theta = pi/8; G = [cos(theta) -sin(theta); sin(theta) cos(theta)];
S{1} = G*[5 0; 0 .1]*G';
theta = 3*pi/4; G = [cos(theta) -sin(theta);sin(theta) cos(theta)];
S{2}= G*[3 0; 0 .5]*G';
S{3} = [1 0; 0 4];
t = [.5   .3  .2;
     .225 .55 .225;
     .5   .3  .2];
 
p = [.3; .4; .3];
[X, cats]= HMM_Generator(N, mu, S, p, t);
K = 3; % number of components

%% Part A 

%Shuffle the data 

%shuffling code taken from : https://www.mathworks.com/matlabcentral/answers/74903-which-algorithm-performs-random-shuffling-of-data-in-matlab-randperm-function
rand_pos = randperm(N); %array of random positions
% new array with original data randomly distributed 
for k = 1:N
    data_randomly_placed(:,k) = X(:,rand_pos(k));
    cats_randomly_placed(:,k) = cats(rand_pos(k));
end


%% Fix the order, apply MAP Rule


% Apply Bayes on GMM parameters
estimated_classes = zeros(N,1);
for i=1:N
    ml = 0;
    for k =1:K
        map = mvnpdf(data_randomly_placed(:,i), mu{k}, S{k}) ;
        if ml<map
            ml = map;
            class = k;
        end
    end
    estimated_classes(i) = class;
end

%Classification Accuracy
true_labelled = 0;
for i=1:N
    if cats_randomly_placed(i) == estimated_classes(i)
        true_labelled = true_labelled +1;
    end
end
accuracy = true_labelled / N;
%% Part B - Viterbi

labels = Viterbi(X, N, K, S, mu,p,t);
true = 0;
for i =1:N
    if labels(i) == cats(i)
        true = true +1;
    end
end
accuracy_viterbi = true/N;