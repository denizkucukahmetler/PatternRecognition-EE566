function [X] = GMM_Generator(N, mu, cov, p)
%This function generates the data with the size N and parameters mu,
%covariance matrix (cov) with respect to the class probabilities given in
%p. 
%The approach taken while generating the data was, generating N numbers
%between 0 and 1 and mapping to the classes considering the class
%probabilities. This approach is taken to randomly draw the data without
%directly generating the instances which makes the process more
%probabilistic. 
    X = zeros(2,N);
    a = 1;
    b = 0;
    r = (b-a).*rand(N,1) + a; %randomly generate N numbers in the range (0,1)
    counts = zeros(N,1);
    for ran=1:N               
        if r(ran) < 0.3                      %map to class 1 if random number is in [0-0.3)
            counts(ran) = 1;
        elseif 0.3<=r(ran) && r(ran) <0.7    %map to class 2 if random number is in [0.3-0.7)
            counts(ran) = 2;  
        else                                 %map to class 3 if random number is in [0.7-1)
            counts(ran) = 3; 
        end
    end
    
    normal_ins = randn(2,N);
    for k=1:N
        j = counts(k);
        [G, D] = eig(cell2mat(cov(j)));
        
        instance = G*sqrt(D)*normal_ins(:,k) +cell2mat(mu(j));
        X(:,k) = instance;
    end
end