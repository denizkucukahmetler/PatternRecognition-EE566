%%
clear all;
N=200;
x = rand(2,N); % generate patterns
wtrue = [3 6]'; % normal vector
btrue = -4.5; % offset
eta = 1./(1+exp(-(wtrue'*x + btrue*ones(1,N)))); % posterior probabilities
y = binornd(ones(1,N),eta); % generate labels
scatter(x(1,find(y==1)),x(2,find(y==1)),'rx')
hold on
scatter(x(1,find(y==0)),x(2,find(y==0)),'bo')
hp0 = -btrue/wtrue(2);
hp1 = -(btrue + wtrue(1))/wtrue(2);
plot([0 1],[hp0 hp1],'Linewidth',2); % plot hyperplane
axis([0 1 0 1]) % fit to region of data


%% PART A - Logistic Regression

%augment 1 to the last row of x
ones_row = ones(1,200);
x = [x;ones_row];

s = @(x) 1/(1+e^(-x)); %sigmoid
%%
v = 0.00001; %step size

lambda = 0.0001; %regularizer

ws = [1 1 1];

i = 1;
g = gradient(ws(i,:), x, y, lambda, N);
w = ws(i, :) - v*g';
ws = [ws; w];

i =2;
while 1
    g = gradient(ws(i,:), x, y, lambda, N);
    w = ws(i,:) - v*g';
    ws = [ws; w];
    i = i+1;
    if abs(ws(i,:)- ws(i-1,:)) <= 0.00001
       break 
    end
end

model = ws(end, :);


hp0 = -w(3)/w(2);
hp1 = -(w(3) + w(1))/w(2);
hold on
plot([0 1],[hp0 hp1],'Linewidth',2);
hold off

%% PART B - LDA

%seperate classes
x0 = zeros(3,length(find(y==0)));
x1 = zeros(3,length(find(y==1)));
for i=1:N
    if y(i) ==0
        x0(:,i) = x(:,i);
    else 
        x1(:,i) = x(:,i);
    end
end
    
%obtain class means
mu0 = mean( x0' );
mu1 = mean( x1' );
sigma = cov(x0');

g = @(x) (mu0-mu1) * sigma * x; %discriminant function

gx = g(x);





