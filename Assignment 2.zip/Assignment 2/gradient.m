function [g] = gradient(w, x, y, lambda, N)


s = @(x) (1/(1+exp(-x))); %sigmoid

g = 0;
for i=1:N
    g = g + (s(w*x(:,i))-y(i))*x(:,i)+2*lambda*w';
end
%g = g/N;
end




