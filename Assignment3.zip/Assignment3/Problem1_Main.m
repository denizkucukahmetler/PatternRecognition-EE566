%Load the dataset

faces = load("yalefaces.mat").yalefaces;
faces_dims = size(faces);
N = faces_dims(3); %Number of Instances
dd = faces_dims(1)*faces_dims(2);
%Flatten the data
data = reshape((faces), dd, N)';
data = double(data);
%Center the data
data_centered = data- mean(data);
%Data covariance


data_covariance = data_centered'*data_centered;
% data_covariance = zeros(dd,dd);
% for n = 1:N
%     ins = data_centered(n,:)'*data_centered(n,:);
%     data_covariance = data_covariance + ins;
% end
data_covariance = (1/(N-1))*data_covariance;
%Eigenvalue Decomposition
[V,D] = eig(data_covariance,'vector');

%Make the eigenvectors in descending order
[ds,ind] = sort(D,'descend');
D = D(ind);
Vs = V(:,ind);
Ds=diag(D);
%% Eigenvector Plot
figure();
for i=1:100
    face = Vs(:,i);
    face = rescale(face, 0,255);
    face = reshape(face, 48,42);
    face = uint8(face);
    subplot(10,10,i);
    imshow((face));
    
    hold on;
end

%% Eigenvalue Plot
semilogx([1:dd], diag(Ds));

%% Energy Coverage
N = 2016;
Ep = @(p) sum(diag(Ds(1:p,1:p)));
E = sum(diag(Ds));
energy_coverage = zeros(1,N);
for j = 1:N
    energy_coverage(j) = Ep(j)/E;
end
semilogx([1:N], energy_coverage)


%% 98% Coverage
p = 102;
coverage = Ep(p)/E;
%102 images should be used to achieve 98% coverage

%% Reconstruction

figure();

hold on;
errors = zeros(1,100);
for p = 1:100
    
    Bp = Vs(:,1:p);
    Z = data_centered*Bp; %Reduced Data Matrix
    disp(size(Z));
    X_h = Z*Bp';

    im = X_h(1,:); %choose the first reconstructed image
    error(p) = sqrt(sum((data_centered(1,:)-im).^2));
    im = rescale(im, 0,255);
    im = reshape(im, 48,42);
    im = uint8(im);
    imshow(im);
    subplot(10,10,p);
    
end
hold off;
%% Plot Mean Square Reconstruction Errors of 100 p
figure();
plot(error);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          DUAL PCA         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = data_centered*data_centered';%Affinity matrix
[U,D] = eig(K,'vector');

%Make the eigenvectors in descending order
[ds,ind] = sort(D,'descend');
D = D(ind);
Us = U(:,ind);
Ds=diag(D);

%% Energy Coverage
N = 2414;
Ep = @(p) sum(diag(Ds(1:p,1:p)));
E = sum(diag(Ds));
energy_coverage = zeros(1,N);
for j = 1:N
    energy_coverage(j) = Ep(j)/E;
end


%% 98% Coverage
p = 102;
coverage = Ep(p)/E
%102 images should be used to achieve 98% coverage
