%% MDS

% %generate data
mu = 1;
sigma = 0.01;
N = 1000;
t = mvnrnd(mu, sigma, N); %1000x1
alphas = unifrnd(0,pi,[N,1]); %1000x1

a = @(alpha,i) t(i,:)*cos(alpha);
b = @(alpha,i) t(i,:)*sin(alpha);
data = zeros(N,2);
labels = zeros(1,N);
figure();
hold on;
for i = 1:N
    x = [a(alphas(i),i),b(alphas(i),i)];
    data(i,:) = x;
    if (alphas(i)<pi/2)
        labels(i) = 0;
        scatter(x(1,1), x(1,2), "MarkerFaceColor","b");
    else 
        labels(i) = 1;
        scatter(x(1,1), x(1,2), 'MarkerFaceColor', "r");
    end
end
hold off;
%% Distance Matrix D
D = zeros(N,N);
for i=1:N
    for j= 1:N
        D(i,j) = [t(i)-t(j),alphas(i)-alphas(j)]*[t(i)-t(j),alphas(i)-alphas(j)]';
    end
end

%% Gram Matrix
e= ones(N,1);
H = eye(N,N)- 1/N*(e*(e)');
K = -0.5*H*D*H;

[U,D] = eig(K,'vector');

%Make the eigenvectors in descending order
[ds,ind] = sort(D,'descend');
D = D(ind);
Us = U(:,ind);
Ds=diag(D);

%% Reconstruct Data with MDS
p = 2;
Z = Us(:,1:p)*sqrt(Ds(1:p,1:p));

figure();
hold on;
for i = 1:N
    x = Z(i,:);%[a(alphas(i),i),b(alphas(i),i)];
    %data(i,:) = x;
    if (alphas(i)<pi/2)
        labels(i) = 0;
        scatter(x(1,1), x(1,2), "MarkerFaceColor","b");
    else 
        labels(i) = 1;
        scatter(x(1,1), x(1,2), 'MarkerFaceColor', "r");
    end
end
hold off;

%% Comparison with PCA
%Center the data
data_centered = data- mean(data);
%Data covariance


data_covariance = data_centered'*data_centered;
data_covariance = (1/(N-1))*data_covariance;
%Eigenvalue Decomposition
[V,D] = eig(data_covariance,'vector');

%Make the eigenvectors in descending order
[ds,ind] = sort(D,'descend');
D = D(ind);
Vs = V(:,ind);
Ds=diag(D);

Bp = Vs(:,1:p);
Z = data_centered*Bp; %Reduced Data Matrix
    disp(size(Z));
    X_h = Z*Bp';

figure();
hold on;
for i = 1:N
    x = Z(i,:);%[a(alphas(i),i),b(alphas(i),i)];
    %data(i,:) = x;
    if (alphas(i)<pi/2)
        labels(i) = 0;
        scatter(x(1,1), x(1,2), "MarkerFaceColor","b");
    else 
        labels(i) = 1;
        scatter(x(1,1), x(1,2), 'MarkerFaceColor', "r");
    end
end
hold off;
